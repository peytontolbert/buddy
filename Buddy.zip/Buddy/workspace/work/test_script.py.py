import flask
print(flask.__version__)