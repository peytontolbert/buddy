class WebBrowserFeatures:
    def __init__(self):
        pass
