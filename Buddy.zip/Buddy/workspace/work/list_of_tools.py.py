# List of tools for creating an HTML web server

tools = [
    'tool1',
    'tool2',
    'tool3'
    # Add more tools here
]