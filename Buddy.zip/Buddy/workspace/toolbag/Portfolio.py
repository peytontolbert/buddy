class Portfolio:
    def __init__(self):
        pass
