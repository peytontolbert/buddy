class JsonSchema:
    schema = {
        "entity1": "description of entity1. Please describe the entities using sentences rather than single words.",
        "entity2": "description of entity2. Please describe the entities using sentences rather than single words.",
        "entity3": "description of entity3. Please describe the entities using sentences rather than single words."
    }
